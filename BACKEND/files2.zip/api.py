"""
Maize Price Forecast API - Minimal Backend
============================================
FastAPI backend for testing the maize price prediction model.
Supports location-based predictions for 1-14 days ahead.

Usage:
    uvicorn api:app --reload
    
Then visit: http://localhost:8000/docs for interactive testing
"""

import os
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error
import joblib
import warnings
from datetime import datetime, timedelta
from typing import Optional, List
from pydantic import BaseModel, Field

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

warnings.filterwarnings("ignore")

# Constants
DATA_PATH = "all_raw__1_.csv"
MODEL_DIR = "models"
HORIZONS = list(range(1, 15))
LAGS = [1, 2, 3, 5, 7, 10, 14, 21, 28]
WINDOWS = [3, 7, 14, 30]

# Cache
_cache = {"df": None, "models": {}, "counties": None}


# ============================================================================
# Data Models
# ============================================================================

class PredictionRequest(BaseModel):
    horizon_days: int = Field(..., ge=1, le=14, description="Days ahead (1-14)")
    county: Optional[str] = Field(None, description="County name (optional)")
    reference_date: Optional[str] = Field(None, description="YYYY-MM-DD format (optional)")


class PredictionResponse(BaseModel):
    date: str
    horizon_days: int
    location: str
    current_price: float
    predicted_price: float
    change_kes: float
    change_percent: float


# ============================================================================
# Data Loading
# ============================================================================

def load_data():
    """Load and aggregate data to daily national median"""
    if _cache["df"] is not None:
        return _cache["df"]
    
    df = pd.read_csv(DATA_PATH)
    df["Date"] = pd.to_datetime(df["Date"])
    
    # Cap at 99th percentile
    p99 = df["Retail"].quantile(0.99)
    df = df[df["Retail"] <= p99].copy()
    
    # Daily median
    daily = (
        df.groupby("Date")
        .agg(price=("Retail", "median"), wholesale=("Wholesale", "median"))
        .reset_index()
        .sort_values("Date")
    )
    
    # Fill missing days
    daily = (
        daily.set_index("Date")
        .resample("D")
        .interpolate(method="linear")
        .reset_index()
    )
    
    _cache["df"] = daily
    print(f"✓ Loaded {len(daily)} days ({daily['Date'].min().date()} → {daily['Date'].max().date()})")
    return daily


def load_county_data():
    """Load per-county data"""
    if _cache["counties"] is not None:
        return _cache["counties"]
    
    df = pd.read_csv(DATA_PATH)
    df["Date"] = pd.to_datetime(df["Date"])
    p99 = df["Retail"].quantile(0.99)
    df = df[df["Retail"] <= p99].copy()
    
    county_data = {}
    for county in df["County"].unique():
        county_df = df[df["County"] == county]
        daily = (
            county_df.groupby("Date")
            .agg(price=("Retail", "median"), wholesale=("Wholesale", "median"))
            .reset_index()
            .sort_values("Date")
        )
        daily = (
            daily.set_index("Date")
            .resample("D")
            .interpolate(method="linear")
            .reset_index()
        )
        county_data[county] = daily
    
    _cache["counties"] = county_data
    print(f"✓ Loaded {len(county_data)} counties")
    return county_data


# ============================================================================
# Feature Engineering
# ============================================================================

def engineer_features(daily: pd.DataFrame) -> pd.DataFrame:
    """Add engineered features to daily series"""
    df = daily.copy()
    min_date = df["Date"].min()
    
    # Time features
    df["trend"] = (df["Date"] - min_date).dt.days
    df["day_of_week"] = df["Date"].dt.dayofweek
    df["month"] = df["Date"].dt.month
    df["week_of_year"] = df["Date"].dt.isocalendar().week.astype(int)
    df["year"] = df["Date"].dt.year
    df["sin_month"] = np.sin(2 * np.pi * df["month"] / 12)
    df["cos_month"] = np.cos(2 * np.pi * df["month"] / 12)
    df["sin_week"] = np.sin(2 * np.pi * df["week_of_year"] / 52)
    df["cos_week"] = np.cos(2 * np.pi * df["week_of_year"] / 52)
    
    # Spread
    df["spread"] = df["price"] - df["wholesale"]
    
    # Lags
    for lag in LAGS:
        df[f"lag_{lag}"] = df["price"].shift(lag)
        df[f"wlag_{lag}"] = df["wholesale"].shift(lag)
        df[f"spread_lag_{lag}"] = df["spread"].shift(lag)
    
    # Rolling stats
    for w in WINDOWS:
        base = df["price"].shift(1)
        df[f"roll_mean_{w}"] = base.rolling(w).mean()
        df[f"roll_std_{w}"] = base.rolling(w).std()
        df[f"roll_min_{w}"] = base.rolling(w).min()
        df[f"roll_max_{w}"] = base.rolling(w).max()
    
    # Momentum
    df["momentum_7"] = df["price"].shift(1) - df["price"].shift(8)
    df["momentum_14"] = df["price"].shift(1) - df["price"].shift(15)
    
    return df.dropna().reset_index(drop=True)


def get_feature_cols(df: pd.DataFrame, horizon: int) -> List[str]:
    """Get valid feature columns (exclude short lags)"""
    excluded = (
        [f"lag_{l}" for l in range(1, horizon)]
        + [f"wlag_{l}" for l in range(1, horizon)]
        + [f"spread_lag_{l}" for l in range(1, horizon)]
    )
    all_cols = [c for c in df.columns if c not in ("Date", "price")]
    return [c for c in all_cols if c not in excluded]


# ============================================================================
# Models
# ============================================================================

def make_model():
    """Create GBR model"""
    return GradientBoostingRegressor(
        n_estimators=400,
        learning_rate=0.05,
        max_depth=4,
        random_state=42,
    )


def train_models(df: pd.DataFrame):
    """Train all 14 horizon models"""
    models = {}
    for h in HORIZONS:
        feat_cols = get_feature_cols(df, h)
        X = df[feat_cols]
        y = df["price"]
        
        model = make_model()
        model.fit(X, y)
        models[h] = (model, feat_cols)
        print(f"  ✓ Trained +{h}d model ({len(feat_cols)} features)")
    
    return models


def load_models():
    """Load or train models"""
    if _cache["models"]:
        return _cache["models"]
    
    models = {}
    missing = []
    
    for h in HORIZONS:
        path = f"{MODEL_DIR}/gbr_horizon_{h:02d}.pkl"
        if os.path.exists(path):
            try:
                models[h] = joblib.load(path)
                print(f"  ✓ Loaded +{h}d model")
            except:
                missing.append(h)
        else:
            missing.append(h)
    
    if missing:
        print(f"Training {len(missing)} models...")
        df = load_data()
        df = engineer_features(df)
        trained = train_models(df)
        models.update(trained)
    
    _cache["models"] = models
    return models


# ============================================================================
# Prediction
# ============================================================================

def make_feature_row(price_hist, ws_hist, target_date, min_date):
    """Create feature vector for a date"""
    p = price_hist
    w = ws_hist
    
    row = {
        "trend": (target_date - min_date).days,
        "day_of_week": target_date.dayofweek,
        "month": target_date.month,
        "week_of_year": target_date.isocalendar()[1],
        "year": target_date.year,
        "sin_month": np.sin(2 * np.pi * target_date.month / 12),
        "cos_month": np.cos(2 * np.pi * target_date.month / 12),
        "sin_week": np.sin(2 * np.pi * target_date.isocalendar()[1] / 52),
        "cos_week": np.cos(2 * np.pi * target_date.isocalendar()[1] / 52),
        "spread": (p[-1] - w[-1]) if p and w else 0.0,
    }
    
    for lag in LAGS:
        row[f"lag_{lag}"] = p[-lag] if len(p) >= lag else np.nan
        row[f"wlag_{lag}"] = w[-lag] if len(w) >= lag else np.nan
        row[f"spread_lag_{lag}"] = (p[-lag] - w[-lag]) if len(p) >= lag else np.nan
    
    for window in WINDOWS:
        window_data = p[-window:] if len(p) >= window else p
        row[f"roll_mean_{window}"] = float(np.mean(window_data)) if window_data else np.nan
        row[f"roll_std_{window}"] = float(np.std(window_data)) if window_data else np.nan
        row[f"roll_min_{window}"] = float(np.min(window_data)) if window_data else np.nan
        row[f"roll_max_{window}"] = float(np.max(window_data)) if window_data else np.nan
    
    row["momentum_7"] = (p[-1] - p[-8]) if len(p) >= 8 else 0.0
    row["momentum_14"] = (p[-1] - p[-15]) if len(p) >= 15 else 0.0
    
    return row


def predict(daily_df: pd.DataFrame, horizon: int, reference_date=None):
    """Predict for a horizon"""
    models = load_models()
    if horizon not in models:
        raise ValueError(f"Invalid horizon: {horizon}")
    
    model, feat_cols = models[horizon]
    
    if reference_date is None:
        reference_date = daily_df["Date"].max()
    
    target_date = reference_date + timedelta(days=horizon)
    min_date = daily_df["Date"].min()
    
    price_hist = list(daily_df["price"])
    ws_hist = list(daily_df["wholesale"])
    
    row = make_feature_row(price_hist, ws_hist, target_date, min_date)
    X = pd.DataFrame([row])[feat_cols].fillna(0)
    
    return float(model.predict(X)[0])


# ============================================================================
# FastAPI App
# ============================================================================

app = FastAPI(title="Maize Price Forecast API", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup():
    """Load data and models on startup"""
    print("\n[Startup] Loading data and models...")
    load_data()
    load_county_data()
    load_models()
    print("[Startup] ✓ Ready\n")


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "name": "Maize Price Forecast API",
        "endpoints": {
            "predict": "POST /predict",
            "counties": "GET /counties",
            "docs": "GET /docs",
        },
    }


@app.get("/counties")
async def get_counties():
    """Get list of available counties"""
    counties = load_county_data()
    return {"counties": sorted(counties.keys()), "total": len(counties)}


@app.post("/predict", response_model=PredictionResponse)
async def make_prediction(request: PredictionRequest):
    """
    Get maize price prediction for a location and time range.
    
    Example:
        {"horizon_days": 7, "county": "Kiambu"}
    """
    try:
        # Load data
        if request.county:
            counties = load_county_data()
            if request.county not in counties:
                raise HTTPException(status_code=400, detail=f"County '{request.county}' not found")
            daily_df = counties[request.county]
            location = request.county
        else:
            daily_df = load_data()
            location = "National (Median)"
        
        # Reference date
        if request.reference_date:
            ref_date = pd.to_datetime(request.reference_date)
        else:
            ref_date = daily_df["Date"].max()
        
        # Engineer features
        daily_engineered = engineer_features(daily_df)
        
        # Current price
        current_price = daily_df[daily_df["Date"] <= ref_date]["price"].iloc[-1]
        
        # Predict
        predicted_price = predict(daily_engineered, request.horizon_days, ref_date)
        
        # Calculate change
        change = predicted_price - current_price
        change_pct = (change / current_price) * 100
        
        # Target date
        target_date = ref_date + timedelta(days=request.horizon_days)
        
        return PredictionResponse(
            date=target_date.strftime("%Y-%m-%d"),
            horizon_days=request.horizon_days,
            location=location,
            current_price=round(current_price, 2),
            predicted_price=round(predicted_price, 2),
            change_kes=round(change, 2),
            change_percent=round(change_pct, 2),
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
